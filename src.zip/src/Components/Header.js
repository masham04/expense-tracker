import React from 'react'

export const Header = () => {
    return (
        <div>
            <h1>
                Expense Tracker
            </h1>
        </div>
    )
}
